Testing layouts with custom inflection:
<?php echo $this->placeholder('Zend_Layout')->message ?>

