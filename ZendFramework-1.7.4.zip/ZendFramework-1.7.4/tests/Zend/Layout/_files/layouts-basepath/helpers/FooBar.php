<?php

class Layout_View_Helper_FooBar
{
    
    public function fooBar()
    {
        return 'foobar-helper-output';
    }
    
}