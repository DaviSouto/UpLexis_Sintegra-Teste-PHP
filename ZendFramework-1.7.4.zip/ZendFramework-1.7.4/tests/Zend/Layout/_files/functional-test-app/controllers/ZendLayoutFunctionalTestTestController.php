<?php

class ZendLayoutFunctionalTestTestController extends Zend_Controller_Action
{
    
    public function indexAction()
    {

    }
    
    public function missingViewScriptAction()
    {
    }
    
}