<?php

class ZendLayoutFunctionalTestErrorController extends Zend_Controller_Action
{
    
    public function errorAction()
    {
    }
    
}