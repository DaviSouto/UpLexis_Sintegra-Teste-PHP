<?php
/**
 * Zend Framework
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://framework.zend.com/license/new-bsd
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@zend.com so we can send you a copy immediately.
 *
 * @category    ZendX
 * @package     ZendX_JQuery
 * @subpackage  View
 * @copyright   Copyright (c) 2005-2008 Zend Technologies USA Inc. (http://www.zend.com)
 * @license     http://framework.zend.com/license/new-bsd     New BSD License
 * @version     $Id: AccordionContainerTest.php 11837 2008-10-10 15:58:41Z matthew $
 */

require_once dirname(__FILE__)."/../../../TestHelper.php";

if (!defined('PHPUnit_MAIN_METHOD')) {
    define('PHPUnit_MAIN_METHOD', 'ZendX_JQuery_View_AccordionTest::main');
}

require_once "Zend/Registry.php";
require_once "Zend/View.php";
require_once "ZendX/JQuery.php";
require_once "ZendX/JQuery/View/Helper/JQuery.php";

require_once "ZendX/JQuery/View/Helper/AccordionContainer.php";

class ZendX_JQuery_View_AccordionContainerTest extends PHPUnit_Framework_TestCase
{
	private $view = null;
	private $jquery = null;
	private $helper = null;

    /**
     * Runs the test methods of this class.
     *
     * @return void
     */
    public static function main()
    {
        $suite  = new PHPUnit_Framework_TestSuite("ZendX_JQuery_View_AccordionContainerTest");
        $result = PHPUnit_TextUI_TestRunner::run($suite);
    }

	public function setUp()
	{
        Zend_Registry::_unsetInstance();
        $this->view   = $this->getView();
        $this->jquery = new ZendX_JQuery_View_Helper_JQuery_Container();
        $this->jquery->setView($this->view);
        Zend_Registry::set('ZendX_JQuery_View_Helper_JQuery', $this->jquery);
	}

	public function tearDown()
	{
		ZendX_JQuery_View_Helper_JQuery::disableNoConflictMode();
	}

    public function getView()
    {
        require_once 'Zend/View.php';
        $view = new Zend_View();
        $view->addHelperPath('ZendX/JQuery/View/Helper/', 'ZendX_JQuery_View_Helper');
        return $view;
    }

    public function testCallingInViewEnablesJQueryHelper()
    {
        $element = $this->view->accordionContainer();

        $this->assertTrue($this->jquery->isEnabled());
        $this->assertTrue($this->jquery->uiIsEnabled());
        $this->assertTrue($element instanceof ZendX_JQuery_View_Helper_AccordionContainer);
    }

    public function testShouldAppendToJqueryHelper()
    {
        $this->view->accordionContainer()->addPane("elem1", "test1", "test1");
        $element = $this->view->accordionContainer("elem1", array('option' => 'true'), array());

        $jquery = $this->view->jQuery()->__toString();
        $this->assertContains('accordion(', $jquery);
        $this->assertContains('"option":"true"', $jquery);
    }

    public function testShouldReturnEmptyStringIfEmpty()
    {
        $accordion = $this->view->accordionContainer("empty", array(), array());

        $this->assertEquals('', $accordion);
    }

    public function testShouldAllowAddingTabs()
    {
        $accordion = $this->view->accordionContainer()->addPane("container1", "elem1", "Text1")
                        ->addPane("container1", "elem2", "Text2")
                        ->accordionContainer("container1", array(), array());

        $this->assertEquals(array('$("#container1").accordion({});'), $this->jquery->getOnLoadActions());
        $this->assertContains("elem1", $accordion);
        $this->assertContains("Text1", $accordion);
        $this->assertContains("elem2", $accordion);
        $this->assertContains("Text2", $accordion);
    }

    public function testShouldAllowAddingMultipleTabs()
    {
        $this->view->accordionContainer()->addPane("container1", "elem1", "Text1")
             ->addPane("container2", "elem2", "Text2");

        $accordion = $this->view->accordionContainer("container1", array(), array());
        $accordion2 = $this->view->accordionContainer("container2", array(), array());

        $this->assertEquals(array('$("#container1").accordion({});', '$("#container2").accordion({});'), $this->jquery->getOnLoadActions());
        $this->assertNotContains("elem1", $accordion2);
        $this->assertNotContains("Text1", $accordion2);
        $this->assertContains("elem1", $accordion);
        $this->assertContains("Text1", $accordion);
        $this->assertNotContains("elem2", $accordion);
        $this->assertNotContains("Text2", $accordion);
        $this->assertContains("elem2", $accordion2);
        $this->assertContains("Text2", $accordion2);
    }

    public function testShouldAllowCaptureTabContent()
    {
        $this->view->accordionPane()->captureStart("container1", "elem1");
        echo "Lorem Ipsum!";
        $this->view->accordionPane()->captureEnd("container1");

        $this->view->accordionPane()->captureStart("container1", "elem2", array('contentUrl' => 'foo.html'));
        echo "This is captured and displayed: contentUrl does not exist for Accordion.";
        $this->view->accordionPane()->captureEnd("container1");

        $accordion = $this->view->accordionContainer("container1", array(), array());

        $this->assertEquals(array('$("#container1").accordion({});'), $this->jquery->getOnLoadActions());
        $this->assertContains('elem1', $accordion);
        $this->assertContains('elem2', $accordion);
        $this->assertContains('Lorem Ipsum!', $accordion);
        $this->assertNotContains('href="foo.html"', $accordion);
        $this->assertContains('This is captured and displayed: contentUrl does not exist for Accordion.', $accordion);
    }

    public function testShouldAllowUsingTabPane()
    {
        $this->view->accordionPane("container1", "Lorem Ipsum!", array('title' => 'elem1'));
        $this->view->accordionPane("container1", 'This is captured and displayed: contentUrl does not exist for Accordion.', array('title' => 'elem2', 'contentUrl' => 'foo.html'));

        $accordion = $this->view->accordionContainer("container1", array(), array());

        $this->assertEquals(array('$("#container1").accordion({});'), $this->jquery->getOnLoadActions());
        $this->assertContains('elem1', $accordion);
        $this->assertContains('elem2', $accordion);
        $this->assertContains('Lorem Ipsum!', $accordion);
        $this->assertNotContains('href="foo.html"', $accordion);
        $this->assertContains('This is captured and displayed: contentUrl does not exist for Accordion.', $accordion);
    }
}

if (PHPUnit_MAIN_METHOD == 'ZendX_JQuery_View_AccordionContainerTest::main') {
    ZendX_JQuery_View_AccordionContainerTest::main();
}