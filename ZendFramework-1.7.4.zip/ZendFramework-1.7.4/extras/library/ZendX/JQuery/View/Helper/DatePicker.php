<?php
/**
 * Zend Framework
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://framework.zend.com/license/new-bsd
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@zend.com so we can send you a copy immediately.
 *
 * @category    ZendX
 * @package     ZendX_JQuery
 * @subpackage  View
 * @copyright   Copyright (c) 2005-2008 Zend Technologies USA Inc. (http://www.zend.com)
 * @license     http://framework.zend.com/license/new-bsd     New BSD License
 * @version     $Id: DatePicker.php 11941 2008-10-13 19:41:38Z matthew $
 */

/**
 * @see Zend_Registry
 */
require_once "Zend/Registry.php";

/**
 * @see ZendX_JQuery_View_Helper_UiWidget
 */
require_once "ZendX/JQuery/View/Helper/UiWidget.php";

/**
 * jQuery Date Picker View Helper
 *
 * @uses 	   Zend_Json, Zend_View_Helper_FormText
 * @package    ZendX_JQuery
 * @subpackage View
 * @copyright  Copyright (c) 2005-2008 Zend Technologies USA Inc. (http://www.zend.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 */
class ZendX_JQuery_View_Helper_DatePicker extends ZendX_JQuery_View_Helper_UiWidget
{
	/**
	 * Create a jQuery UI Widget Date Picker
	 *
	 * @link   http://docs.jquery.com/UI/Datepicker
	 * @param  string $id
	 * @param  string $value
	 * @param  array  $params jQuery Widget Parameters
	 * @param  array  $attribs HTML Element Attributes
	 * @return string
	 */
	public function datePicker($id, $value = null, array $params = array(), array $attribs = array())
	{
		$attribs = $this->_prepareAttributes($id, $value, $attribs);

		//
		// Prepare params
		//
		if(!isset($params['dateFormat']) && Zend_Registry::isRegistered('Zend_Locale')) {
		    $params['dateFormat'] = $this->_resolveLocaleToDatePickerFormat();
		}

		// TODO: Allow translation of DatePicker Text Values to get this action from client to server

		if(count($params) > 0) {
		    /**
		     * @see Zend_Json
		     */
		    require_once "Zend/Json.php";
		    $params = Zend_Json::encode($params);
		} else {
		    $params = "{}";
		}

		$js = sprintf('%s("#%s").datepicker(%s);',
		    ZendX_JQuery_View_Helper_JQuery::getJQueryHandler(),
		    $attribs['id'],
		    $params
		);

		//
		// Add DatePicker callup to onLoad Stack
		//
		$this->jquery->addOnLoad($js);

		return $this->view->formText($id, $value, $attribs);
	}

	/**
	 * A Check for Zend_Locale existance has already been done in {@link datePicker()}
	 * this function only resolves the default format from Zend Locale to
	 * a jQuery Date Picker readable format. This function can be potentially buggy
	 * because of its easy nature and is therefore stripped from the core functionality
	 * to be easily overriden.
	 *
	 * @return string
	 */
	protected function _resolveLocaleToDatePickerFormat()
	{
	    $locale = Zend_Registry::get('Zend_Locale');
	    require_once "Zend/Locale/Format.php";
	    $dateFormat = str_replace(
	        array('EEE', 'EEEE', 'M', 'MM', 'MMM', 'MMMM', 'YY', 'YYYY', 'yyyy'),
	        array('D', 'DD', 'm', 'mm', 'M', 'MM', 'y', 'yy', 'yy'),
	        Zend_Locale_Format::getDateFormat($locale)
	    );

	    return $dateFormat;
	}
}