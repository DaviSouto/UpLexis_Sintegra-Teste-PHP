<?php
/**
 * File header here
 * 
 * @author Ralph Schindler <ralph.schindler@zend.com>
 */



/**
 * class docblock
 *
 * @package Zend_Reflection_TestSampleSingleClass
 */
class Zend_Reflection_TestSampleSingleClass
{
    
    /**
     * Enter description here...
     *
     * @return bool
     */
    public function someMethod()
    {  
        /* test test */    
    }
    
}

