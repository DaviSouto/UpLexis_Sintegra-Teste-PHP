<?php

require_once 'Zend/Tool/Framework/Exception.php';

class Zend_Tool_Framework_Client_Exception extends Zend_Tool_Framework_Exception
{
}