<?php

require_once 'Zend/Tool/Framework/Provider/Action.php';

class Zend_Tool_Framework_System_Action_Delete extends Zend_Tool_Framework_Provider_Action
{}