<?php

require_once 'Zend/Exception.php';

class Zend_Tool_Framework_Exception extends Zend_Exception 
{
}