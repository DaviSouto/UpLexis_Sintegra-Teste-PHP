<?php

interface Zend_Tool_Framework_Provider_Interface
{ 
}