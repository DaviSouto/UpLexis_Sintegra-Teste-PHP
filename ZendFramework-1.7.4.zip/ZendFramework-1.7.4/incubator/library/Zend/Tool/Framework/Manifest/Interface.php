<?php

interface Zend_Tool_Framework_Manifest_Interface
{
    
    //public function getMetadata();
    
}