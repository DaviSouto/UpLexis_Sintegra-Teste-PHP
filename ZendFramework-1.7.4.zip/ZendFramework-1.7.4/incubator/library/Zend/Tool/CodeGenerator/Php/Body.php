<?php

require_once 'Zend/Tool/CodeGenerator/Abstract.php';

class Zend_Tool_CodeGenerator_Php_Body extends Zend_Tool_CodeGenerator_Abstract
{
    public function generate() {}
}
