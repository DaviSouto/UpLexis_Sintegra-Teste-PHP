<?php

require_once 'Zend/Tool/CodeGenerator/Exception.php';

class Zend_Tool_CodeGenerator_Php_Exception extends Zend_Tool_CodeGenerator_Exception
{}
