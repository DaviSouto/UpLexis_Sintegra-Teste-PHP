<?php

require_once 'Zend/Exception.php';

class Zend_Tool_CodeGenerator_Exception extends Zend_Exception
{}