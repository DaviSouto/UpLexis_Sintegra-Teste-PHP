<?php

class Zend_Tool_Project_Provider_DbTable extends Zend_Tool_Project_Provider_Abstract
{

    public function create()
    {
        
    }
    
    public function delete()
    {
        
    }

}
