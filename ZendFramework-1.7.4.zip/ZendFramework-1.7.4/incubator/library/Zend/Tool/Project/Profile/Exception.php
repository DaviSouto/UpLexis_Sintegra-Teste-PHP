<?php

require_once 'Zend/Tool/Project/Exception.php';

class Zend_Tool_Project_Profile_Exception extends Zend_Tool_Project_Exception
{}