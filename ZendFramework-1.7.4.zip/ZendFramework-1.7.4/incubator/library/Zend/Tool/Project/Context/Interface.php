<?php

interface Zend_Tool_Project_Context_Interface
{
    
    public function getName();
    
}
