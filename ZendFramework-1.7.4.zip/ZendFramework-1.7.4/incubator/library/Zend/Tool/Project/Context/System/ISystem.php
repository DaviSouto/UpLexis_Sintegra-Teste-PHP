<?php

interface Zend_Tool_Project_Context_System_ISystem
{
}