<?php

require_once 'Zend/Exception.php';

class Zend_Tool_Project_Exception extends Zend_Exception
{}