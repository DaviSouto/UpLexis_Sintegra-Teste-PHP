<?php

require_once 'Zend/Exception.php';

class Zend_Reflection_Exception extends Zend_Exception
{}